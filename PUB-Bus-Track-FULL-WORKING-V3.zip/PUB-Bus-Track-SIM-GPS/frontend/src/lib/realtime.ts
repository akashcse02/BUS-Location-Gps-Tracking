import { io, type Socket } from "socket.io-client";

const TOKEN_KEY = "pub_bus_track_token";
let socket: Socket | null = null;

function backendOrigin() {
  const base = (import.meta as any)?.env?.VITE_API_URL || `${window.location.protocol}//${window.location.hostname}:5000/api`;
  return String(base).replace(/\/api\/?$/, "");
}

export function connectRealtime() {
  if (typeof window === "undefined") return null;
  const token = window.localStorage.getItem(TOKEN_KEY);
  if (!token) return null;
  if (socket?.connected) return socket;
  socket = io(backendOrigin(), { auth: { token }, transports: ["websocket", "polling"] });
  return socket;
}

export function disconnectRealtime() {
  socket?.disconnect();
  socket = null;
}

export function realtimeSocket() {
  return socket || connectRealtime();
}
