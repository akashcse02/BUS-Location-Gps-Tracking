import { createFileRoute, redirect, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowLeft, Save, UserRound, Settings2 } from "lucide-react";
import { toast } from "sonner";
import { getMyProfile, updateMyProfile } from "@/integrations/backend/client";
import { useLanguage } from "@/lib/i18n";

export const Route = createFileRoute("/profile")({
  ssr: false,
  loader: async () => {
    const result = await getMyProfile();
    if (!result.res.ok) throw redirect({ to: "/login" });
    return result.json;
  },
  head: () => ({ title: "Profile — PUB Bus Track" }),
  component: ProfilePage,
});

function ProfilePage() {
  const navigate = useNavigate();
  const { lang, setLang } = useLanguage();
  const data = Route.useLoaderData();
  const initial = data?.profile || {};
  const [form, setForm] = useState({
    full_name: initial.full_name || "",
    id_number: initial.id_number || "",
    department: initial.department || "",
    phone_number: initial.phone_number || "",
    avatar_url: initial.avatar_url || "",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm({
      full_name: initial.full_name || "",
      id_number: initial.id_number || "",
      department: initial.department || "",
      phone_number: initial.phone_number || "",
      avatar_url: initial.avatar_url || "",
    });
  }, [initial.full_name, initial.id_number, initial.department, initial.phone_number, initial.avatar_url]);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const result = await updateMyProfile({
      full_name: form.full_name,
      id_number: form.id_number || null,
      department: form.department || null,
      phone_number: form.phone_number || null,
      avatar_url: form.avatar_url || null,
    });
    setSaving(false);
    if (!result.res.ok) {
      toast.error(result.json?.message || "Could not save profile");
      return;
    }
    toast.success("Profile updated");
    navigate({ to: "/dashboard" });
  };

  const initialLetter = (form.full_name || "PUB").charAt(0).toUpperCase();

  return (
    <main className="min-h-screen bg-slate-50 px-5 py-8 sm:px-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex items-center justify-between gap-4">
          <Link to="/dashboard" className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-bold text-ink/70 shadow-sm ring-1 ring-slate-200 hover:text-ink">
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Link>
          <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-black uppercase tracking-widest text-primary">{data?.role || "student"}</span>
        </div>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          <Card className="rounded-[2rem]">
            <CardContent className="flex flex-col items-center p-8 text-center">
              <Avatar className="h-28 w-28 border-4 border-primary/10 shadow-lg">
                <AvatarImage src={form.avatar_url || undefined} />
                <AvatarFallback className="bg-primary/10 text-3xl font-black text-primary">{initialLetter}</AvatarFallback>
              </Avatar>
              <p className="mt-5 font-display text-xl font-black text-ink">{form.full_name || "PUB User"}</p>
              <p className="mt-1 text-sm font-medium text-ink/50">{data?.email}</p>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="rounded-[2rem]">
              <CardHeader><CardTitle className="flex items-center gap-2 text-xl"><UserRound className="h-5 w-5 text-primary" /> Profile Information</CardTitle></CardHeader>
              <CardContent>
                <form onSubmit={save} className="grid gap-5 sm:grid-cols-2">
                  <div className="sm:col-span-2"><Label htmlFor="full_name">Full Name</Label><Input id="full_name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} className="mt-2 h-12 rounded-xl" required /></div>
                  <div><Label htmlFor="id_number">ID Number</Label><Input id="id_number" value={form.id_number} onChange={(e) => setForm({ ...form, id_number: e.target.value })} className="mt-2 h-12 rounded-xl" /></div>
                  <div><Label htmlFor="department">Department</Label><Input id="department" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} className="mt-2 h-12 rounded-xl" /></div>
                  <div><Label htmlFor="phone_number">Phone Number</Label><Input id="phone_number" value={form.phone_number} onChange={(e) => setForm({ ...form, phone_number: e.target.value })} className="mt-2 h-12 rounded-xl" /></div>
                  <div><Label htmlFor="avatar_url">Avatar URL</Label><Input id="avatar_url" value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} className="mt-2 h-12 rounded-xl" placeholder="https://..." /></div>
                  <div className="sm:col-span-2"><Label>Email</Label><Input value={data?.email || ""} disabled className="mt-2 h-12 rounded-xl bg-slate-50" /></div>
                  <div className="flex justify-end sm:col-span-2"><Button disabled={saving} type="submit" className="h-12 rounded-xl px-6 font-bold"><Save className="mr-2 h-4 w-4" />{saving ? "Saving..." : "Save Changes"}</Button></div>
                </form>
              </CardContent>
            </Card>

            <Card className="rounded-[2rem]">
              <CardHeader><CardTitle className="flex items-center gap-2 text-xl"><Settings2 className="h-5 w-5 text-primary" /> Preferences</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl bg-slate-50 p-4">
                  <div><p className="font-bold text-ink">Language</p><p className="text-xs text-ink/50">Dashboard and public pages</p></div>
                  <select value={lang} onChange={(e) => setLang(e.target.value as any)} className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold"><option value="en">English</option><option value="bn">বাংলা</option><option value="ar">العربية</option></select>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
