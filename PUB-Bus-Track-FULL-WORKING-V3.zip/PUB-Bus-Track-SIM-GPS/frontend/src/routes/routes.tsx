import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, MapPin, Bus as BusIcon, Clock3 } from "lucide-react";
import { getRoutes, getBuses, getBusSchedules } from "@/integrations/backend/client";
import { realtimeSocket } from "@/lib/realtime";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/routes")({
  head: () => ({ title: "Routes | PUB Bus Track", meta: [{ name: "description", content: "Live university bus routes, stops and timings." }] }),
  component: RoutesPage,
});

function RoutesPage() {
  const [routes, setRoutes] = useState<any[]>([]);
  const [buses, setBuses] = useState<any[]>([]);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    setLoading(true);
    const [routeRes, busRes, scheduleRes] = await Promise.all([getRoutes(), getBuses(), getBusSchedules()]);
    if (!routeRes.res.ok) setError(routeRes.json?.message || "Could not load routes. Please login.");
    else setError("");
    setRoutes(Array.isArray(routeRes.json?.data) ? routeRes.json.data : []);
    setBuses(Array.isArray(busRes.json?.data) ? busRes.json.data : []);
    setSchedules(Array.isArray(scheduleRes.json?.data) ? scheduleRes.json.data : []);
    setLoading(false);
  };

  useEffect(() => {
    void load();
    const socket = realtimeSocket();
    const refresh = () => void load();
    socket?.on("data_changed", refresh);
    return () => socket?.off("data_changed", refresh);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return routes;
    return routes.filter((r) => `${r.name} ${r.description || ""} ${(r.stops || []).map((s: any) => s.name).join(" ")}`.toLowerCase().includes(q));
  }, [routes, query]);

  return (
    <div className="min-h-screen bg-slate-50 px-5 py-10 sm:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-primary">PUB Transportation</p>
            <h1 className="mt-2 font-display text-4xl font-black text-ink">Routes & Stops</h1>
            <p className="mt-2 max-w-2xl text-ink/60">Live routes loaded from MongoDB. Admin changes are pushed to this page automatically.</p>
          </div>
          <div className="relative w-full sm:max-w-sm">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-ink/30" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search route or stop..." className="h-13 w-full rounded-2xl border-0 bg-white pl-12 pr-4 shadow-sm ring-1 ring-slate-200 outline-none focus:ring-2 focus:ring-primary" />
          </div>
        </div>

        {loading && <div className="rounded-3xl bg-white p-10 text-center shadow-sm">Loading routes...</div>}
        {!loading && error && <div className="rounded-3xl bg-white p-10 text-center shadow-sm"><p className="font-bold text-red-500">{error}</p><Link to="/login" className="mt-4 inline-block rounded-xl bg-primary px-5 py-3 font-bold text-white">Login</Link></div>}
        {!loading && !error && filtered.length === 0 && <div className="rounded-3xl bg-white p-10 text-center shadow-sm">No routes found.</div>}

        <div className="grid gap-6 lg:grid-cols-2">
          {filtered.map((route) => {
            const assigned = buses.filter((b) => b.current_route_id === route.id);
            const routeSchedules = schedules.filter((s) => s.route_id === route.id);
            return <article key={route.id} className="rounded-[2rem] bg-white p-6 shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-xl">
              <div className="flex items-start justify-between gap-4">
                <div><h2 className="font-display text-2xl font-black text-ink">{route.name}</h2><p className="mt-1 text-sm text-ink/50">{route.description}</p></div>
                <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-black text-primary">{(route.stops || []).length} stops</span>
              </div>
              <div className="mt-5 space-y-3">
                {(route.stops || []).map((stop: any, index: number) => <div key={`${route.id}-${index}`} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary/10 text-xs font-black text-primary">{index + 1}</span><MapPin className="h-4 w-4 text-primary" /><span className="font-bold text-ink">{stop.name}</span><span className="ml-auto text-xs text-ink/40">{stop.position?.lat?.toFixed?.(4)}, {stop.position?.lng?.toFixed?.(4)}</span></div>)}
              </div>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <div className="rounded-2xl bg-sky-50 p-4"><div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-sky-700"><BusIcon className="h-4 w-4" /> Assigned buses</div><p className="mt-2 text-lg font-black text-ink">{assigned.length}</p><p className="text-xs text-ink/50">{assigned.map((b) => b.bus_number).join(", ") || "No bus assigned"}</p></div>
                <div className="rounded-2xl bg-emerald-50 p-4"><div className="flex items-center gap-2 text-xs font-black uppercase tracking-wider text-emerald-700"><Clock3 className="h-4 w-4" /> Timings</div><p className="mt-2 text-sm font-black text-ink">{routeSchedules.length ? routeSchedules.map((s) => `${s.day_of_week} ${s.departure_time}${s.arrival_time ? ` → ${s.arrival_time}` : ""}`).join(" · ") : "No schedule published"}</p><p className="text-xs text-ink/50">Admin changes appear automatically.</p></div>
              </div>
            </article>;
          })}
        </div>
      </div>
    </div>
  );
}
