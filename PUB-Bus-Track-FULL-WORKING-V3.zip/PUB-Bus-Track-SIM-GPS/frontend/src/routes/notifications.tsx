import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Bell, Megaphone, AlertCircle } from "lucide-react";
import { getAnnouncements } from "@/integrations/backend/client";
import { realtimeSocket } from "@/lib/realtime";

export const Route = createFileRoute("/notifications")({
  ssr: false,
  loader: async () => {
    const raw = window.localStorage.getItem("pub_bus_track_token");
    if (!raw) throw redirect({ to: "/login" });
    return null;
  },
  head: () => ({ title: "Notifications — PUB Bus Track" }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const result = await getAnnouncements();
    if (!result.res.ok) setError(result.json?.message || "Could not load notifications");
    else setError("");
    setAnnouncements(Array.isArray(result.json?.data) ? result.json.data : []);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const socket = realtimeSocket();
    socket?.on("data_changed", load);
    socket?.on("sos", load);
    return () => {
      socket?.off("data_changed", load);
      socket?.off("sos", load);
    };
  }, [load]);

  return (
    <main className="min-h-screen bg-slate-50 px-5 py-8 sm:px-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <Link to="/dashboard" className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-bold text-ink/70 shadow-sm ring-1 ring-slate-200"><ArrowLeft className="h-4 w-4" /> Back to Dashboard</Link>
        <Card className="rounded-[2rem]">
          <CardHeader><CardTitle className="flex items-center gap-2 font-display text-2xl"><Bell className="h-6 w-6 text-primary" /> Notifications</CardTitle><p className="text-sm text-ink/50">Announcements and operational updates from PUB Bus Track.</p></CardHeader>
          <CardContent className="space-y-3">
            {loading ? <p className="text-sm font-medium text-ink/50">Loading notifications...</p> : error ? <p className="rounded-2xl bg-red-50 p-4 text-sm font-bold text-red-600">{error}</p> : announcements.length === 0 ? <p className="rounded-2xl bg-slate-50 p-5 text-sm font-medium text-ink/50">No notifications yet.</p> : announcements.map((a) => (
              <article key={a.id} className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm">
                <div className="flex items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary"><Megaphone className="h-5 w-5" /></span><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold text-ink">{a.title}</h3><span className="text-[10px] font-bold uppercase tracking-wider text-ink/35">{a.target_role || "All users"}</span></div><p className="mt-1 text-sm leading-6 text-ink/65">{a.content}</p><p className="mt-2 text-[11px] font-semibold text-ink/35">{a.created_at ? new Date(a.created_at).toLocaleString() : ""}</p></div></div>
              </article>
            ))}
          </CardContent>
        </Card>
        <div className="rounded-2xl bg-primary/5 p-4 text-sm text-ink/60"><div className="flex items-start gap-3"><AlertCircle className="mt-0.5 h-4 w-4 text-primary" /><p>SOS emergencies are sent directly to the admin queue and appear there in real time.</p></div></div>
      </div>
    </main>
  );
}
