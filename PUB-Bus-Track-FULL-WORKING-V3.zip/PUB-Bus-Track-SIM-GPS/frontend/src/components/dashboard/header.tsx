import { useEffect, useState } from "react";
import { Search, Bell, LogOut, UserRound, Settings2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link, useNavigate } from "@tanstack/react-router";
import { db } from "@/integrations/backend/client";
import { toast } from "sonner";

export function Header({ profile }: { profile: any }) {
  const [dhakaTime, setDhakaTime] = useState("");
  const [search, setSearch] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const tick = () => setDhakaTime(new Intl.DateTimeFormat("en-BD", { timeZone: "Asia/Dhaka", dateStyle: "medium", timeStyle: "short" }).format(new Date()));
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = search.trim();
    if (!q) return;
    window.location.href = `/buses?search=${encodeURIComponent(q)}`;
  };

  const logout = async () => {
    await db.auth.signOut();
    toast.success("Logged out successfully");
    navigate({ to: "/login" });
  };

  return (
    <header className="sticky top-0 z-20 flex h-20 items-center justify-between border-b border-slate-200 bg-white px-5 shadow-sm sm:px-8">
      <form onSubmit={submitSearch} className="relative w-full max-w-xl">
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ink/30" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search bus, route, or driver..." className="h-11 w-full rounded-2xl border-none bg-slate-50 pl-11 ring-1 ring-slate-100 focus:bg-white" />
      </form>

      <div className="ml-4 flex items-center gap-3 sm:gap-4">
        <div className="hidden rounded-2xl bg-primary/5 px-4 py-2 text-right md:block">
          <p className="text-[9px] font-black uppercase tracking-widest text-primary/60">Dhaka Time</p>
          <p className="text-xs font-bold text-ink">{dhakaTime}</p>
        </div>

        <button type="button" onClick={() => navigate({ to: "/notifications" })} className="relative rounded-xl p-2 transition-all hover:bg-slate-50" aria-label="Notifications">
          <Bell className="h-5 w-5 text-ink/60" />
          <span className="absolute right-2 top-2 h-2 w-2 rounded-full border-2 border-white bg-red-500" />
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger className="outline-none">
            <div className="flex items-center gap-3 rounded-2xl py-1 pl-2 pr-1 transition-all hover:bg-slate-50">
              <div className="hidden text-right sm:block">
                <p className="text-sm font-bold leading-tight text-ink">{profile?.full_name || "PUB User"}</p>
                <p className="text-xs font-medium leading-tight text-ink/40">{profile?.id_number || "ID Number"}</p>
              </div>
              <Avatar className="h-10 w-10 border-2 border-primary/10 shadow-sm">
                <AvatarImage src={profile?.avatar_url || undefined} />
                <AvatarFallback className="bg-primary/5 font-bold text-primary">{profile?.full_name?.charAt(0)?.toUpperCase() || "P"}</AvatarFallback>
              </Avatar>
            </div>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="mt-2 w-56 rounded-2xl border-none p-2 shadow-2xl" align="end">
            <DropdownMenuLabel className="px-3 py-2 text-[10px] font-bold uppercase tracking-widest text-ink/40">Account</DropdownMenuLabel>
            <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-3 font-bold" onClick={() => navigate({ to: "/profile" })}>
              <UserRound className="mr-2 h-4 w-4" /> Profile
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-3 font-bold" onClick={() => navigate({ to: "/profile" })}>
              <Settings2 className="mr-2 h-4 w-4" /> Preferences
            </DropdownMenuItem>
            <DropdownMenuSeparator className="my-2 bg-slate-50" />
            <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-3 font-bold text-red-500" onClick={() => void logout()}>
              <LogOut className="mr-2 h-4 w-4" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
