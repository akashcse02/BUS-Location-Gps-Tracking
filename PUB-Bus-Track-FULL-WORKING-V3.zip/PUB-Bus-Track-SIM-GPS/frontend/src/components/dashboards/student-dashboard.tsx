import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "@tanstack/react-router";
import { Map, CalendarDays, Bus as BusIcon, Clock3, Megaphone, Navigation, RefreshCw } from "lucide-react";
import { GoogleLiveMap } from "@/components/maps/google-live-map";
import { ReviewForm } from "@/components/reviews/review-form";
import { ReportIssueForm } from "@/components/issues/report-issue-form";
import { useLanguage } from "@/lib/i18n";
import { getAnnouncements, getBusSchedules, trackingLive } from "@/integrations/backend/client";
import { realtimeSocket } from "@/lib/realtime";
import { Button } from "@/components/ui/button";

type LiveRow = Record<string, any>;

type ProfileLike = {
  bus_id?: string | null;
};

export function StudentDashboard({
  userId,
  displayName,
  profile,
}: {
  userId: string;
  displayName: string;
  profile?: ProfileLike | null;
}) {
  const { t } = useLanguage();
  const [liveRows, setLiveRows] = useState<LiveRow[]>([]);
  const [schedules, setSchedules] = useState<any[]>([]);
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [liveRes, scheduleRes, announcementsRes] = await Promise.all([
      trackingLive(),
      getBusSchedules(),
      getAnnouncements(),
    ]);
    setLiveRows(liveRes.res.ok && Array.isArray(liveRes.json?.data) ? liveRes.json.data : []);
    setSchedules(scheduleRes.res.ok && Array.isArray(scheduleRes.json?.data) ? scheduleRes.json.data : []);
    setAnnouncements(announcementsRes.res.ok && Array.isArray(announcementsRes.json?.data) ? announcementsRes.json.data.slice(0, 5) : []);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const socket = realtimeSocket();
    const refresh = () => void load();
    socket?.on("gps_update", refresh);
    socket?.on("trip_update", refresh);
    socket?.on("data_changed", refresh);
    const timer = window.setInterval(load, 15000);
    return () => {
      window.clearInterval(timer);
      socket?.off("gps_update", refresh);
      socket?.off("trip_update", refresh);
      socket?.off("data_changed", refresh);
    };
  }, [load]);

  const active = useMemo(
    () => liveRows.filter((row) => row.trip_status === "in_progress" || row.trip_status === "delayed"),
    [liveRows],
  );
  const gpsCount = useMemo(
    () => liveRows.filter((row) => typeof row.current_lat === "number" && typeof row.current_lng === "number").length,
    [liveRows],
  );
  const assignedBus = profile?.bus_id ? liveRows.find((row) => row.bus_id === profile.bus_id) : null;
  const focusBuses = assignedBus ? [assignedBus] : liveRows;
  const nextSchedule = schedules.find((row) => row.active) || schedules[0] || null;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <SummaryCard icon={<BusIcon className="h-5 w-5" />} label="Buses" value={liveRows.length} />
        <SummaryCard icon={<Navigation className="h-5 w-5" />} label="Live trips" value={active.length} />
        <SummaryCard icon={<Map className="h-5 w-5" />} label="GPS connected" value={gpsCount} />
        <SummaryCard icon={<Clock3 className="h-5 w-5" />} label="Next bus" value={nextSchedule ? nextSchedule.departure_time?.slice(0, 5) || "—" : "—"} />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="overflow-hidden rounded-[2rem] shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between gap-4">
              <div>
                <CardTitle className="font-display text-2xl font-bold">{t("dash.liveBus")}</CardTitle>
                <p className="text-sm font-medium text-ink/50">Live bus positions, route lines and stops.</p>
              </div>
              <Button variant="outline" size="icon" className="rounded-xl" onClick={() => void load()} disabled={loading}>
                <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              </Button>
            </CardHeader>
            <CardContent className="h-[500px] p-0 pt-0">
              <GoogleLiveMap
                buses={focusBuses.map((row) => ({
                  id: row.bus_id,
                  busNumber: row.bus_number,
                  location: {
                    lat: typeof row.current_lat === "number" ? row.current_lat : row.route?.stops?.[0]?.position?.lat || 24.9223067,
                    lng: typeof row.current_lng === "number" ? row.current_lng : row.route?.stops?.[0]?.position?.lng || 89.3490259,
                  },
                  occupancy: row.occupancy,
                  status: row.trip_status === "in_progress" ? "Live" : row.trip_status,
                  nextStop: row.nextStop,
                  etaMinutes: row.etaMinutes,
                  lastUpdated: row.last_gps_at,
                }))}
              />
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="rounded-[2rem]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><BusIcon className="h-5 w-5 text-primary" /> Bus status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {liveRows.length === 0 ? (
                  <p className="text-sm font-medium text-ink/50">No buses are available right now.</p>
                ) : (
                  liveRows.slice(0, 6).map((row) => (
                    <div key={row.bus_id} className="flex items-center justify-between rounded-2xl bg-slate-50 p-3">
                      <div>
                        <p className="font-bold text-ink">{row.bus_number}</p>
                        <p className="text-xs font-medium text-ink/50">{row.route_name || "Unassigned route"}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-xs font-black ${row.trip_status === "in_progress" ? "text-emerald-600" : row.trip_status === "delayed" ? "text-orange-600" : "text-ink/40"}`}>
                          {row.trip_status === "in_progress" ? "LIVE" : String(row.trip_status).replace("_", " ").toUpperCase()}
                        </p>
                        <p className="text-[10px] font-semibold text-ink/40">{row.nextStop ? `Next: ${row.nextStop}` : "GPS standby"}</p>
                      </div>
                    </div>
                  ))
                )}
                <Link to="/buses" className="block pt-1 text-sm font-bold text-primary hover:underline">View all buses →</Link>
              </CardContent>
            </Card>

            <Card className="rounded-[2rem]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg"><Megaphone className="h-5 w-5 text-primary" /> Announcements</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {announcements.length === 0 ? (
                  <p className="text-sm font-medium text-ink/50">No announcements yet.</p>
                ) : (
                  announcements.map((a) => (
                    <div key={a.id} className="rounded-2xl bg-slate-50 p-3">
                      <p className="font-bold text-ink">{a.title}</p>
                      <p className="mt-1 line-clamp-2 text-xs leading-5 text-ink/60">{a.content}</p>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="rounded-[2rem]">
            <CardHeader>
              <CardTitle className="text-lg">{t("dash.yourBus")}</CardTitle>
            </CardHeader>
            <CardContent>
              {assignedBus ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-black text-ink">{assignedBus.bus_number}</p>
                      <p className="text-sm text-slate-500">{assignedBus.route_name || "Route unavailable"}</p>
                    </div>
                    <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-black text-primary">Assigned</span>
                  </div>
                  <InfoLine label="Status" value={assignedBus.trip_status === "in_progress" ? "Live" : String(assignedBus.trip_status).replace("_", " ")} />
                  <InfoLine label="Next Stop" value={assignedBus.nextStop || "Not available"} />
                  <InfoLine label="ETA" value={assignedBus.etaMinutes ? `${assignedBus.etaMinutes} min` : "Not available"} />
                  <Link to="/live-location" className="block rounded-xl bg-primary px-4 py-3 text-center text-sm font-bold text-white hover:opacity-90">Track my bus</Link>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm font-medium leading-6 text-slate-500">
                    No personal bus assignment is stored yet. You can still use the live map to follow any university bus.
                  </p>
                  <Link to="/live-location" className="block rounded-xl bg-primary px-4 py-3 text-center text-sm font-bold text-white">Open live map</Link>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="rounded-[2rem]">
            <CardHeader>
              <CardTitle className="text-lg">Quick Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <QuickLink to="/live-location" icon={Map} label={t("dash.viewMap")} />
              <QuickLink to="/time-schedule" icon={CalendarDays} label={t("dash.viewSchedule")} />
              <QuickLink to="/buses" icon={BusIcon} label={t("dash.viewBuses")} />
            </CardContent>
          </Card>
        </div>
      </div>

      <ReviewForm userId={userId} displayName={displayName} roleLabel="Student" />
      <ReportIssueForm />
    </div>
  );
}

function SummaryCard({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) {
  return (
    <Card className="rounded-3xl border-none p-5 shadow-sm ring-1 ring-black/5">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">{icon}</span>
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-ink/40">{label}</p>
          <p className="font-display text-2xl font-black text-ink">{value}</p>
        </div>
      </div>
    </Card>
  );
}

function InfoLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-sm">
      <span className="font-semibold text-ink/50">{label}</span>
      <span className="font-black text-ink">{value}</span>
    </div>
  );
}

function QuickLink({ to, icon: Icon, label }: { to: "/live-location" | "/time-schedule" | "/buses"; icon: typeof Map; label: string }) {
  return (
    <Link to={to} className="flex items-center gap-3 rounded-2xl px-4 py-3 font-bold text-ink/70 transition-all hover:bg-slate-50 hover:text-primary">
      <Icon className="h-5 w-5" />
      {label}
    </Link>
  );
}
