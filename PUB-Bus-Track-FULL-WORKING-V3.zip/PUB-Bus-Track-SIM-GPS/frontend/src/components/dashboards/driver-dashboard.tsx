import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Play, AlertTriangle, Users, MapPin, Navigation, Clock3, RefreshCw, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import {
  getBuses,
  trackingHistory,
  trackingLocation,
  trackingMine,
  trackingOccupancy,
  trackingSOS,
  trackingStart,
  trackingStatus,
} from "@/integrations/backend/client";
import { GoogleLiveMap } from "@/components/maps/google-live-map";
import { realtimeSocket } from "@/lib/realtime";

export function DriverDashboard({ driverId }: { driverId: string }) {
  const [isTripActive, setIsTripActive] = useState(false);
  const [currentTripId, setCurrentTripId] = useState<string | null>(null);
  const [occupancy, setOccupancy] = useState<"low" | "medium" | "high">("low");
  const [mine, setMine] = useState<any>(null);
  const [buses, setBuses] = useState<any[]>([]);
  const [historyCount, setHistoryCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const intervalRef = useRef<ReturnType<typeof window.setInterval> | null>(null);

  const load = useCallback(async () => {
    const [mineRes, busRes] = await Promise.all([trackingMine(), getBuses()]);
    const trip = mineRes.res.ok ? mineRes.json?.data : null;
    setMine(trip);
    setBuses(busRes.res.ok && Array.isArray(busRes.json?.data) ? busRes.json.data : []);
    if (trip) {
      setCurrentTripId(trip.id);
      setIsTripActive(true);
      setOccupancy(trip.occupancy || "low");
      const history = await trackingHistory(trip.bus_id, 200);
      setHistoryCount(history.res.ok && Array.isArray(history.json?.data) ? history.json.data.length : 0);
    } else {
      setCurrentTripId(null);
      setIsTripActive(false);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const socket = realtimeSocket();
    const refresh = () => void load();
    socket?.on("gps_update", refresh);
    socket?.on("trip_update", refresh);
    return () => {
      socket?.off("gps_update", refresh);
      socket?.off("trip_update", refresh);
      if (intervalRef.current) window.clearInterval(intervalRef.current);
    };
  }, [load]);

  const stopBroadcasting = () => {
    if (intervalRef.current) {
      window.clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const sendLocation = useCallback((tripId: string) => {
    if (!navigator.geolocation) {
      toast.error("This device does not support GPS.");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const response = await trackingLocation(tripId, {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          speed: Number.isFinite(position.coords.speed as number) ? Number(position.coords.speed) * 3.6 : null,
          bearing: Number.isFinite(position.coords.heading as number) ? Number(position.coords.heading) : null,
          accuracy: Number.isFinite(position.coords.accuracy) ? Number(position.coords.accuracy) : null,
        });
        if (!response.res.ok) toast.error(response.json?.message || "GPS update failed");
      },
      (error) => toast.error(`GPS error: ${error.message}`),
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 },
    );
  }, []);

  const startTrip = async () => {
    try {
      const result = await trackingStart({ occupancy });
      const trip = result.json?.data;
      if (!result.res.ok || !trip) throw new Error(result.json?.message || "Could not start trip");
      setCurrentTripId(trip.id);
      setIsTripActive(true);
      toast.success("Trip started. GPS broadcasting is active.");
      sendLocation(trip.id);
      stopBroadcasting();
      intervalRef.current = window.setInterval(() => sendLocation(trip.id), 10000);
      await load();
    } catch (error: any) {
      toast.error(error.message || "Could not start trip");
    }
  };

  const endTrip = async () => {
    if (!currentTripId) return;
    try {
      const result = await trackingStatus(currentTripId, "completed");
      if (!result.res.ok) throw new Error(result.json?.message || "Could not end trip");
      stopBroadcasting();
      setIsTripActive(false);
      setCurrentTripId(null);
      toast.success("Trip completed");
      await load();
    } catch (error: any) {
      toast.error(error.message || "Could not end trip");
    }
  };

  const handleStatus = async (status: "in_progress" | "delayed") => {
    if (!currentTripId) return;
    const result = await trackingStatus(currentTripId, status);
    if (!result.res.ok) toast.error(result.json?.message || "Could not update trip status");
    else await load();
  };

  const handleOccupancyChange = async (level: "low" | "medium" | "high") => {
    setOccupancy(level);
    if (!currentTripId) return;
    const result = await trackingOccupancy(currentTripId, level);
    if (!result.res.ok) toast.error(result.json?.message || "Could not update occupancy");
    else setMine((prev: any) => (prev ? { ...prev, occupancy: level } : prev));
  };

  const handleSOS = async () => {
    const send = async (lat?: number, lng?: number) => {
      const result = await trackingSOS({
        tripId: currentTripId || undefined,
        lat,
        lng,
        message: "Driver pressed SOS / Emergency",
      });
      if (!result.res.ok) toast.error(result.json?.message || "SOS failed");
      else toast.error("Emergency alert sent to admin");
      await load();
    };
    if (!navigator.geolocation) return send();
    navigator.geolocation.getCurrentPosition((p) => void send(p.coords.latitude, p.coords.longitude), () => void send(), { enableHighAccuracy: true, timeout: 8000, maximumAge: 1000 });
  };

  const assignedBus = mine?.bus || buses.find((bus) => bus.driver_id === driverId) || null;
  const firstStop = mine?.route?.stops?.[0]?.position || mine?.route?.stops?.[0] || null;
  const mapBus = mine?.bus_id
    ? [{
        id: mine.bus_id,
        busNumber: mine.bus?.bus_number || "PUB Bus",
        location: {
          lat: typeof mine.current_lat === "number" ? mine.current_lat : Number(firstStop?.lat ?? 24.9223067),
          lng: typeof mine.current_lng === "number" ? mine.current_lng : Number(firstStop?.lng ?? 89.3490259),
        },
        occupancy: mine.occupancy,
        status: mine.status || "not_started",
        nextStop: mine.nextStop,
        etaMinutes: mine.etaMinutes,
        lastUpdated: mine.last_gps_at,
      }]
    : [];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <DriverStat icon={<BusIcon />} label="Assigned Bus" value={assignedBus?.bus_number || "Not assigned"} />
        <DriverStat icon={<Navigation />} label="Trip" value={isTripActive ? (mine?.status || "In progress") : "Not started"} />
        <DriverStat icon={<Users />} label="Occupancy" value={occupancy} />
        <DriverStat icon={<MapPin />} label="GPS points" value={historyCount} />
      </div>

      <div className="grid grid-cols-1 gap-6 xl:grid-cols-5">
        <Card className="rounded-[2rem] shadow-sm xl:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-display text-2xl">
              <Play className={`h-6 w-6 ${isTripActive ? "text-green-500" : "text-slate-300"}`} />
              Trip Controls
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between rounded-2xl border border-slate-100 bg-slate-50 p-5">
              <div>
                <p className="font-bold text-ink">Trip Status</p>
                <p className="text-sm text-ink/60">{isTripActive ? "GPS broadcasting is active." : "Ready to start a new trip."}</p>
              </div>
              <Switch checked={isTripActive} onCheckedChange={(value) => (value ? void startTrip() : void endTrip())} />
            </div>

            <div className="grid grid-cols-3 gap-3">
              {(["low", "medium", "high"] as const).map((level) => (
                <Button key={level} variant={occupancy === level ? "default" : "outline"} className="h-12 rounded-xl font-bold capitalize" onClick={() => void handleOccupancyChange(level)}>{level}</Button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="h-12 rounded-xl font-bold" disabled={!currentTripId} onClick={() => void handleStatus("in_progress")}>Running</Button>
              <Button variant="outline" className="h-12 rounded-xl font-bold" disabled={!currentTripId} onClick={() => void handleStatus("delayed")}>Mark Delayed</Button>
            </div>

            <Button variant="destructive" className="h-14 w-full rounded-xl font-bold shadow-lg" onClick={() => void handleSOS()}>
              <AlertTriangle className="mr-2 h-5 w-5" /> SOS / Emergency
            </Button>
          </CardContent>
        </Card>

        <Card className="overflow-hidden rounded-[2rem] border-none bg-white shadow-sm xl:col-span-3">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="font-display text-2xl">Live Trip Map</CardTitle>
              <p className="text-sm font-medium text-ink/50">Your current GPS position and route are updated in realtime.</p>
            </div>
            <Button variant="outline" size="icon" className="rounded-xl" onClick={() => void load()} disabled={loading}><RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /></Button>
          </CardHeader>
          <CardContent className="h-[440px] p-0">
            <GoogleLiveMap buses={mapBus} />
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-[2rem] border-none bg-slate-900 text-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-display text-2xl">Current Route</CardTitle>
        </CardHeader>
        <CardContent>
          {mine?.route ? (
            <div className="grid gap-3 md:grid-cols-2">
              {(mine.route.stops || []).map((stop: any, index: number) => (
                <div key={`${mine.route.id}-${index}`} className="flex items-center gap-3 rounded-2xl bg-white/5 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 font-black">{index + 1}</div>
                  <div>
                    <p className="font-bold">{stop.name}</p>
                    <p className="text-xs text-white/50">{index === 0 ? "Start" : index === (mine.route.stops.length - 1) ? "Destination" : index === 1 ? (mine.nextStop ? `Next stop · ${mine.nextStop}` : "Upcoming stop") : "Stop"}</p>
                  </div>
                  {mine.nextStop === stop.name && <span className="ml-auto rounded-full bg-emerald-400/15 px-2 py-1 text-[10px] font-black text-emerald-300">NEXT</span>}
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-2xl bg-white/5 p-5 text-sm text-white/60">Start a trip to load your assigned route and stops.</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function DriverStat({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) {
  return (
    <Card className="rounded-3xl border-none p-5 shadow-sm ring-1 ring-black/5">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-primary/10 text-primary">{icon}</span>
        <div className="min-w-0">
          <p className="text-[10px] font-black uppercase tracking-widest text-ink/40">{label}</p>
          <p className="truncate font-display text-xl font-black text-ink capitalize">{String(value)}</p>
        </div>
      </div>
    </Card>
  );
}

function BusIcon() {
  return <span className="text-sm font-black">BUS</span>;
}
