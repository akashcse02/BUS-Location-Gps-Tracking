# PUB Bus Tracer — Full GPS/SIM + MongoDB + Socket.io

Real-time university bus tracking system for Pundra University using React/TanStack Router, Node.js/Express, MongoDB, Socket.io, and ESP32 + NEO-6M GPS with a SIM/GSM/4G data link.

## Architecture

ESP32 + NEO-6M + SIM/GSM → `POST /api/gps/update` → Express → MongoDB → Socket.io → authenticated web clients.

The browser never talks directly to the GPS device. Each bus has a unique GPS device ID and secret device token.

## Features

- Student, Teacher, Driver and Admin authentication
- Signup only for Student / Teacher / Driver
- 6-digit email verification before login
- Two pre-seeded Admin accounts from `.env`
- JWT session authentication and role protection
- Bus-mounted GPS + SIM device ingestion
- GPS latitude/longitude/speed/bearing/accuracy/satellites/history
- Automatic active trip creation for a provisioned bus
- GPS offline detection
- Socket.io live GPS updates and database change events
- MongoDB source of truth for routes, buses, schedules, trips, users, issues, reviews, announcements and config
- Dynamic Routes page with search/filter
- Admin CRUD APIs for routes, buses, bus schedules, users, announcements and app config
- Admin changes broadcast to connected browsers
- Asia/Dhaka live clock in dashboard
- OpenStreetMap live map (no Google Maps API required)
- Responsive login/signup with campus background image and larger cards
- Local GPS simulator for testing without hardware

## Backend setup

```bash
cd backend
npm install
copy .env.example .env
npm run seed
npm run dev
```

Linux/macOS:

```bash
cp .env.example .env
```

## Frontend setup

```bash
cd frontend
npm install
npm run dev
```

## Environment

Required:

```env
MONGODB_URI=mongodb://127.0.0.1:27017/pub_bus_track
JWT_SECRET=replace_with_a_long_random_secret
PORT=5000
CLIENT_URL=http://localhost:5173
```

Admin seed:

```env
ADMIN_EMAIL_1=admin1@pub.ac.bd
ADMIN_EMAIL_2=admin2@pub.ac.bd
ADMIN_PASSWORD=change_this_password
```

Email verification:

```env
RESEND_API_KEY=
EMAIL_FROM=PUB Bus Track <onboarding@resend.dev>
```

For production, use a verified sender domain.

## GPS device API

Endpoint:

```http
POST /api/gps/update
Content-Type: application/json
```

Body:

```json
{
  "device_id": "GPS-PUB-01",
  "device_token": "YOUR_DEVICE_TOKEN",
  "latitude": 24.9223,
  "longitude": 89.3490,
  "speed_kmh": 28,
  "bearing": 90,
  "accuracy_m": 8,
  "satellites": 9,
  "device_time": "2026-09-30T10:00:00Z"
}
```

The backend validates the device credentials, stores the current trip position and appends a GPS history point.

Heartbeat:

```http
POST /api/device/heartbeat
```

## Main APIs

- `GET /api/health`
- `POST /api/auth/signup`
- `POST /api/auth/verify-email`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/session`
- `GET /api/routes`
- `GET /api/buses`
- `GET /api/schedules`
- `GET /api/bus-schedules`
- `GET /api/announcements`
- `GET /api/tracking/live`
- `POST /api/tracking/start`
- `PATCH /api/tracking/:tripId/location`
- `PATCH /api/tracking/:tripId/status`
- `PATCH /api/tracking/:tripId/occupancy`
- `POST /api/tracking/sos`
- `GET /api/tracking/bus/:busId/history`
- `POST /api/gps/update`

Admin CRUD examples:

- `POST/PUT/DELETE /api/routes/:id`
- `POST/PUT/DELETE /api/buses/:id`
- `POST/PUT/DELETE /api/bus-schedules/:id`
- `PUT/DELETE /api/users/:id`
- `POST/PUT/DELETE /api/announcements/:id`
- `PUT /api/config/:key`

## GPS simulator

After `npm run seed`, copy the device ID/token printed for a bus:

PowerShell:

```powershell
cd backend
$env:DEVICE_ID="GPS-PUB-01"
$env:DEVICE_TOKEN="YOUR_SEEDED_TOKEN"
npm run simulate:gps
```

## Important production note

A physical SIM/GPS device cannot call `localhost` on a developer PC. Deploy the Express backend to a public HTTPS URL and configure the ESP32 firmware to send GPS packets to that URL.
