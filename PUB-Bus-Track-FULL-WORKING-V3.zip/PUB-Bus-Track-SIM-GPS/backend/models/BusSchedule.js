import mongoose from "mongoose";
import { idPlugin } from "../lib/idPlugin.js";

const busScheduleSchema = new mongoose.Schema({
  route_id: { type: String, required: true, index: true },
  bus_id: { type: String, default: null, index: true },
  day_of_week: { type: String, required: true },
  departure_time: { type: String, required: true },
  arrival_time: { type: String, default: null },
  active: { type: Boolean, default: true },
}, { timestamps: { createdAt: "created_at", updatedAt: "updated_at" } });
busScheduleSchema.plugin(idPlugin);
export default mongoose.model("BusSchedule", busScheduleSchema);
