import express from "express";
import { registry, publicReadTables } from "../lib/registry.js";
import { runQuery } from "../lib/queryEngine.js";
import UserRole from "../models/UserRole.js";
import { emitRealtime } from "../lib/realtime.js";

const router = express.Router();

function addEqFilter(spec, column, value) {
  const filters = Array.isArray(spec.filters) ? [...spec.filters] : [];
  filters.push([column, "eq", value]);
  spec.filters = filters;
}

router.post("/:table", async (req, res) => {
  const { table } = req.params;
  const Model = registry[table];
  if (!Model) return res.status(404).json({ data: null, error: { message: `Unknown table: ${table}` } });

  const spec = { ...(req.body || {}) };
  const isWrite = spec.action !== "select";
  const isPublicRead = spec.action === "select" && publicReadTables.has(table);

  if ((isWrite || !isPublicRead) && !req.user) {
    return res.status(401).json({ data: null, error: { message: "Not authenticated" } });
  }

  if (isWrite && req.user) {
    const roleDoc = await UserRole.findOne({ user_id: req.user.id }).lean();
    const role = roleDoc?.role;

    if (table === "profiles" && role !== "admin") {
      addEqFilter(spec, "id", req.user.id);
    }

    if (table === "trips") {
      if (spec.action === "insert" && role !== "driver" && role !== "admin") {
        return res.status(403).json({ data: null, error: { message: "Only drivers or admins can start trips" } });
      }
      if (role !== "admin") addEqFilter(spec, "driver_id", req.user.id);
    }

    if (table === "class_schedules" && role !== "teacher" && role !== "admin") {
      return res.status(403).json({ data: null, error: { message: "Teacher or admin access required" } });
    }
    if (table === "class_schedules" && role === "teacher") addEqFilter(spec, "teacher_id", req.user.id);

    if (table === "attendance_records" && role !== "teacher" && role !== "admin") {
      return res.status(403).json({ data: null, error: { message: "Teacher or admin access required" } });
    }
    if (table === "attendance_records" && role === "teacher") addEqFilter(spec, "teacher_id", req.user.id);

    if (table === "announcements" && role !== "teacher" && role !== "admin") {
      return res.status(403).json({ data: null, error: { message: "Teacher or admin access required" } });
    }
    if (table === "announcements" && role === "teacher") addEqFilter(spec, "author_id", req.user.id);

    if (table === "reviews") {
      if (spec.action === "insert" && role !== "admin") {
        const values = Array.isArray(spec.values) ? spec.values : [spec.values];
        spec.values = values.map((v) => ({ ...v, user_id: req.user.id }));
      }
      if (["update", "delete", "upsert"].includes(spec.action) && role !== "admin") {
        return res.status(403).json({ data: null, error: { message: "Only admins can moderate reviews" } });
      }
    }

    if (["routes", "buses", "app_config", "bus_schedules"].includes(table) && role !== "admin") {
      return res.status(403).json({ data: null, error: { message: "Admin access required" } });
    }

    if (table === "user_roles" && role !== "admin") {
      return res.status(403).json({ data: null, error: { message: "Admin access required" } });
    }
  }

  const result = await runQuery(Model, table, spec);
  if (isWrite && !result.error) emitRealtime("data_changed", { resource: table, action: spec.action });
  res.status(result.error ? 400 : 200).json(result);
});

export default router;
