import express from "express";
import { requireAuth, requireAdmin } from "../middleware/auth.js";
import Route from "../models/Route.js";
import Bus from "../models/Bus.js";
import ClassSchedule from "../models/ClassSchedule.js";
import User from "../models/User.js";
import Profile from "../models/Profile.js";
import UserRole from "../models/UserRole.js";
import Announcement from "../models/Announcement.js";
import AppConfig from "../models/AppConfig.js";
import BusSchedule from "../models/BusSchedule.js";
import { emitRealtime } from "../lib/realtime.js";

const router = express.Router();
const models = { routes: Route, buses: Bus, schedules: ClassSchedule, bus_schedules: BusSchedule, users: User, announcements: Announcement, app_config: AppConfig };

function clean(doc) {
  if (!doc) return null;
  const out = doc.toObject ? doc.toObject() : { ...doc };
  delete out._id;
  delete out.__v;
  delete out.password;
  delete out.gps_device_token;
  return out;
}

async function enrichUsers(docs) {
  const ids = docs.map((d) => d.id).filter(Boolean);
  const [profiles, roles] = await Promise.all([
    Profile.find({ id: { $in: ids } }).lean(),
    UserRole.find({ user_id: { $in: ids } }).lean(),
  ]);
  const pm = Object.fromEntries(profiles.map((p) => [p.id, p]));
  const rm = Object.fromEntries(roles.map((r) => [r.user_id, r.role]));
  return docs.map((d) => ({ ...clean(d), profile: pm[d.id] || null, role: rm[d.id] || null }));
}

router.get("/routes", async (_req, res) => {
  const data = await Route.find({}).sort({ name: 1 }).lean();
  res.json({ data: data.map(clean) });
});

router.get("/buses", async (_req, res) => {
  const data = await Bus.find({}).sort({ bus_number: 1 }).lean();
  res.json({ data: data.map(clean) });
});

router.get("/schedules", async (_req, res) => {
  const data = await ClassSchedule.find({}).sort({ day: 1, start_time: 1 }).lean();
  res.json({ data: data.map(clean) });
});

router.get("/bus-schedules", async (_req, res) => {
  const data = await BusSchedule.find({ active: true }).sort({ day_of_week: 1, departure_time: 1 }).lean();
  res.json({ data: data.map(clean) });
});

router.get("/announcements", async (req, res) => {
  let filter = {};
  if (req.user) {
    const roleDoc = await UserRole.findOne({ user_id: req.user.id }).lean();
    const role = roleDoc?.role;
    if (role) filter = { $or: [{ target_role: null }, { target_role: role }] };
  }
  const data = await Announcement.find(filter).sort({ created_at: -1 }).lean();
  res.json({ data: data.map(clean) });
});

router.get("/users", requireAdmin, async (_req, res) => {
  const data = await User.find({}).lean();
  res.json({ data: await enrichUsers(data) });
});

router.put("/users/:id", requireAdmin, async (req, res) => {
  const { full_name, id_number, department, phone_number, role, email_verified } = req.body || {};
  const user = await User.findOne({ id: req.params.id });
  if (!user) return res.status(404).json({ message: "User not found" });
  if (email_verified !== undefined) { user.email_verified = Boolean(email_verified); if (user.email_verified && !user.email_verified_at) user.email_verified_at = new Date(); await user.save(); }
  await Profile.updateOne({ id: user.id }, { $set: { full_name, id_number, department, phone_number } }, { upsert: true });
  if (role) {
    if (!["student", "teacher", "driver", "admin"].includes(role)) return res.status(400).json({ message: "Invalid role" });
    await UserRole.updateOne({ user_id: user.id }, { $set: { role } }, { upsert: true });
  }
  emitRealtime("data_changed", { resource: "users", action: "update", id: user.id });
  res.json({ data: clean(user) });
});

router.delete("/users/:id", requireAdmin, async (req, res) => {
  if (req.params.id === req.user.id) return res.status(400).json({ message: "You cannot delete your own admin account" });
  const result = await User.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "User not found" });
  await Promise.all([Profile.deleteOne({ id: req.params.id }), UserRole.deleteMany({ user_id: req.params.id })]);
  emitRealtime("data_changed", { resource: "users", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

router.put("/routes/:id", requireAdmin, async (req, res) => {
  const doc = await Route.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: "Route not found" });
  emitRealtime("data_changed", { resource: "routes", action: "update", id: doc.id });
  res.json({ data: clean(doc) });
});

router.post("/routes", requireAdmin, async (req, res) => {
  const doc = await Route.create(req.body);
  emitRealtime("data_changed", { resource: "routes", action: "create", id: doc.id });
  res.status(201).json({ data: clean(doc) });
});

router.delete("/routes/:id", requireAdmin, async (req, res) => {
  const result = await Route.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "Route not found" });
  emitRealtime("data_changed", { resource: "routes", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

router.put("/buses/:id", requireAdmin, async (req, res) => {
  const doc = await Bus.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: "Bus not found" });
  emitRealtime("data_changed", { resource: "buses", action: "update", id: doc.id });
  res.json({ data: clean(doc) });
});

router.post("/buses", requireAdmin, async (req, res) => {
  const doc = await Bus.create(req.body);
  emitRealtime("data_changed", { resource: "buses", action: "create", id: doc.id });
  res.status(201).json({ data: clean(doc) });
});

router.delete("/buses/:id", requireAdmin, async (req, res) => {
  const result = await Bus.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "Bus not found" });
  emitRealtime("data_changed", { resource: "buses", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

router.put("/schedules/:id", requireAdmin, async (req, res) => {
  const doc = await ClassSchedule.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: "Schedule not found" });
  emitRealtime("data_changed", { resource: "schedules", action: "update", id: doc.id });
  res.json({ data: clean(doc) });
});

router.post("/schedules", requireAdmin, async (req, res) => {
  const doc = await ClassSchedule.create(req.body);
  emitRealtime("data_changed", { resource: "schedules", action: "create", id: doc.id });
  res.status(201).json({ data: clean(doc) });
});

router.delete("/schedules/:id", requireAdmin, async (req, res) => {
  const result = await ClassSchedule.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "Schedule not found" });
  emitRealtime("data_changed", { resource: "schedules", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

router.get("/config", async (_req, res) => {
  const data = await AppConfig.find({}).lean();
  res.json({ data: data.map(clean) });
});

router.put("/config/:key", requireAdmin, async (req, res) => {
  const doc = await AppConfig.findOneAndUpdate({ key: req.params.key }, { $set: { value: req.body?.value, updated_by: req.user.id } }, { new: true, upsert: true, runValidators: true });
  emitRealtime("data_changed", { resource: "app_config", action: "update", key: req.params.key });
  res.json({ data: clean(doc) });
});

router.post("/bus-schedules", requireAdmin, async (req, res) => {
  const doc = await BusSchedule.create(req.body);
  emitRealtime("data_changed", { resource: "bus_schedules", action: "create", id: doc.id });
  res.status(201).json({ data: clean(doc) });
});

router.put("/bus-schedules/:id", requireAdmin, async (req, res) => {
  const doc = await BusSchedule.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: "Bus schedule not found" });
  emitRealtime("data_changed", { resource: "bus_schedules", action: "update", id: doc.id });
  res.json({ data: clean(doc) });
});

router.delete("/bus-schedules/:id", requireAdmin, async (req, res) => {
  const result = await BusSchedule.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "Bus schedule not found" });
  emitRealtime("data_changed", { resource: "bus_schedules", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

router.put("/announcements/:id", requireAdmin, async (req, res) => {
  const doc = await Announcement.findOneAndUpdate({ id: req.params.id }, { $set: req.body }, { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: "Announcement not found" });
  emitRealtime("data_changed", { resource: "announcements", action: "update", id: doc.id });
  res.json({ data: clean(doc) });
});

router.post("/announcements", requireAdmin, async (req, res) => {
  const doc = await Announcement.create({ ...req.body, author_id: req.user.id });
  emitRealtime("data_changed", { resource: "announcements", action: "create", id: doc.id });
  res.status(201).json({ data: clean(doc) });
});

router.delete("/announcements/:id", requireAdmin, async (req, res) => {
  const result = await Announcement.deleteOne({ id: req.params.id });
  if (!result.deletedCount) return res.status(404).json({ message: "Announcement not found" });
  emitRealtime("data_changed", { resource: "announcements", action: "delete", id: req.params.id });
  res.json({ ok: true });
});

export default router;
