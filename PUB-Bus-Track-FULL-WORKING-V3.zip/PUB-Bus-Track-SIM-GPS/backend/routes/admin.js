import express from "express";
import Route from "../models/Route.js";
import Bus from "../models/Bus.js";
import Profile from "../models/Profile.js";
import UserRole from "../models/UserRole.js";
import { emitRealtime } from "../lib/realtime.js";

const router = express.Router();

async function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ message: "Not authenticated" });
  const role = await UserRole.findOne({ user_id: req.user.id }).lean();
  if (role?.role !== "admin") return res.status(403).json({ message: "Admin access required" });
  next();
}

router.put("/users/:id/assign-bus", requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const busId = req.body?.bus_id ? String(req.body.bus_id) : null;
    const userRole = await UserRole.findOne({ user_id: userId }).lean();
    if (!userRole) return res.status(404).json({ message: "User role not found" });
    if (busId) {
      const bus = await Bus.findOne({ id: busId });
      if (!bus) return res.status(404).json({ message: "Bus not found" });
    }

    await Profile.updateOne(
      { id: userId },
      { $set: { bus_id: busId } },
      { upsert: true },
    );

    if (userRole.role === "driver") {
      await Bus.updateMany({ driver_id: userId }, { $set: { driver_id: null } });
      if (busId) await Bus.updateOne({ id: busId }, { $set: { driver_id: userId } });
    }

    emitRealtime("data_changed", { resource: "users", action: "assign-bus", id: userId, bus_id: busId });
    res.json({ ok: true, bus_id: busId });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.put("/routes/sync", requireAdmin, async (req, res) => {
  try {
    const routes = Array.isArray(req.body?.routes) ? req.body.routes : [];
    if (!routes.length) return res.status(400).json({ message: "At least one route is required" });

    const saved = [];
    for (const item of routes) {
      const name = String(item?.name || "").trim();
      if (!name) continue;
      const stops = Array.isArray(item.stops)
        ? item.stops
            .map((stop) => ({
              name: String(stop?.name || "Stop").trim(),
              position: { lat: Number(stop?.lat), lng: Number(stop?.lng) },
            }))
            .filter((stop) => Number.isFinite(stop.position.lat) && Number.isFinite(stop.position.lng))
        : [];
      const pathPoints = stops.map((stop) => stop.position);
      const existing = await Route.findOne({ name });
      const doc = existing
        ? await Route.findOneAndUpdate(
            { id: existing.id },
            { $set: { description: item.description || `${name} route`, stops, path_points: pathPoints } },
            { new: true },
          )
        : await Route.create({ name, description: item.description || `${name} route`, stops, path_points: pathPoints });
      saved.push(doc.toJSON());
    }

    emitRealtime("data_changed", { resource: "routes", action: "sync" });
    res.json({ data: saved, message: "Routes synchronized with MongoDB" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

export default router;
